#!/usr/bin/env python3

import serial
import sys
from google.cloud import firestore

import random
import string
import threading

# Suppress warnings for not using OAuth2.0 or service accounts for
# authentication. Not a big deal since this is a prototype/poc.
import warnings
warnings.filterwarnings("ignore", "Your application has authenticated using end user credentials")

#warnings.filterwarnings("ignore",'Thread-ConsumeBidirectionalStream caught unexpected exception')

if __name__ == '__main__':
    print("Logging in...")

    db = firestore.Client()

    print("Fetching data...")
    
    # Hard coded temporarily (for demo)
    poll = db.collection(u'Polls').document(u'Bq0FfyttA9iObAKxBnqO')
    
    newQRCode = ""

    def generateQR():
        # Generate random string
        threading.Timer(15.1, generateQR).start()
        newQRCode = ''.join(random.choice(string.printable) for i in range(10)) 
        poll.update({'qrcode': newQRCode})
    
    # Start thread
    generateQR()
    
    port = serial.Serial('/dev/ttyUSB0', timeout=1)

    # Send new qr code to Arduino
    def onNewQRCode(pollSnapshot, change, time):
        print(pollSnapshot)
        for i in pollSnapshot:
            print(i)
        
        qrString = str(pollSnapshot[0].to_dict()['qrcode'])

        print("Writing to serial...")

        port.write(bytes(qrString, encoding='utf8'))
    
    # Start thread
    doc_watch = poll.on_snapshot(onNewQRCode)

    # Run program forever until quit
    for line in sys.stdin:
        line = line.rstrip()
        if line == 'quit':
            break
        print('Type "quit" to exit.')
   
    print("Closing serial and cloud connection...")
    doc_watch.unsubscribe()
    port.close()
